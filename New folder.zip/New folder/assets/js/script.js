$('.owl-carousel').owlCarousel({
    loop: true,
    nav: false,
    dots: true,
    margin: 10,
    responsiveClass: true,
    responsive: {
        0: {
            items: 1,
        },
        600: {
            items: 1,
        },
        1000: {
            items: 1,
        }
    }
})
$(document).ready(function () {
    $('.features-collapse .nav-link').find('.inner-text').hide();
    $('.features-collapse .nav-link.active').find('.inner-text').addClass('d-flex').collapse('show');
    $('.features-collapse .nav-link').click(function () {
        $(this).find('.inner-text').addClass('d-flex').collapse('show');
        $('.features-collapse .nav-link.active').find('.inner-text').removeClass('d-flex').collapse('hide');
        if ($(this).hasClass('active')) {
            $('.features-collapse .nav-link.active').find('.inner-text').removeClass('collapse collapsing').css({
                'display': 'flex',
                'height': '100% !important'
            });
        }
        else{
            $('.features-collapse .nav-link.active').find('.inner-text').addClass('collapse').css({
                'display': 'none',
                'height': '100% !important'
            });
        }
    });

});
new WOW().init();
























const slider = $(".slider-item");
slider.slick({
    dots: true,
    draggable: true,
    arrows: false,
    dots: true,
    speed: 1500,
    infinite: true,
  });

slider.on('wheel', (function(e) {
  e.preventDefault();

  if (e.originalEvent.deltaY < 0) {
    $(this).slick('slickNext');
  } else {
    $(this).slick('slickPrev');
  }
}));